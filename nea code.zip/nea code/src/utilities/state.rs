#[derive(PartialEq)]
pub enum State{
    Menu,
    CreateSim,
    RunSim,
    LoadSave,
    NewSim,
    SaveSim,
    Exit,
}